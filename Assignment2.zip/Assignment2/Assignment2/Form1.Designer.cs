﻿
namespace Assignment2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nameLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nameFiled = new System.Windows.Forms.TextBox();
            this.nameRequired = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.emailRequired = new System.Windows.Forms.Label();
            this.passwordLabel = new System.Windows.Forms.Label();
            this.passwordRequired = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.saveBtn = new System.Windows.Forms.Button();
            this.allRequiredMessage = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.allMessage = new System.Windows.Forms.Label();
            this.warning = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.Location = new System.Drawing.Point(192, 99);
            this.nameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(51, 20);
            this.nameLabel.TabIndex = 0;
            this.nameLabel.Text = "Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(525, 46);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 1;
            // 
            // nameFiled
            // 
            this.nameFiled.Location = new System.Drawing.Point(346, 95);
            this.nameFiled.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nameFiled.Name = "nameFiled";
            this.nameFiled.Size = new System.Drawing.Size(409, 26);
            this.nameFiled.TabIndex = 2;
            this.nameFiled.TextChanged += new System.EventHandler(this.nameFiled_TextChanged);
            // 
            // nameRequired
            // 
            this.nameRequired.AutoSize = true;
            this.nameRequired.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameRequired.ForeColor = System.Drawing.Color.Red;
            this.nameRequired.Location = new System.Drawing.Point(782, 102);
            this.nameRequired.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nameRequired.Name = "nameRequired";
            this.nameRequired.Size = new System.Drawing.Size(13, 16);
            this.nameRequired.TabIndex = 3;
            this.nameRequired.Text = "*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(192, 175);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Email";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(346, 175);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(409, 26);
            this.textBox1.TabIndex = 5;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // emailRequired
            // 
            this.emailRequired.AutoSize = true;
            this.emailRequired.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailRequired.ForeColor = System.Drawing.Color.Red;
            this.emailRequired.Location = new System.Drawing.Point(782, 180);
            this.emailRequired.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emailRequired.Name = "emailRequired";
            this.emailRequired.Size = new System.Drawing.Size(13, 16);
            this.emailRequired.TabIndex = 6;
            this.emailRequired.Text = "*";
            // 
            // passwordLabel
            // 
            this.passwordLabel.AutoSize = true;
            this.passwordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordLabel.Location = new System.Drawing.Point(192, 255);
            this.passwordLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.passwordLabel.Name = "passwordLabel";
            this.passwordLabel.Size = new System.Drawing.Size(55, 20);
            this.passwordLabel.TabIndex = 7;
            this.passwordLabel.Text = "Phone";
            // 
            // passwordRequired
            // 
            this.passwordRequired.AutoSize = true;
            this.passwordRequired.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordRequired.ForeColor = System.Drawing.Color.Red;
            this.passwordRequired.Location = new System.Drawing.Point(782, 258);
            this.passwordRequired.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.passwordRequired.Name = "passwordRequired";
            this.passwordRequired.Size = new System.Drawing.Size(13, 16);
            this.passwordRequired.TabIndex = 8;
            this.passwordRequired.Text = "*";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(346, 252);
            this.textBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(409, 26);
            this.textBox2.TabIndex = 9;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // saveBtn
            // 
            this.saveBtn.Location = new System.Drawing.Point(346, 444);
            this.saveBtn.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(409, 51);
            this.saveBtn.TabIndex = 10;
            this.saveBtn.Text = "Save";
            this.saveBtn.UseVisualStyleBackColor = true;
            this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
            // 
            // allRequiredMessage
            // 
            this.allRequiredMessage.AutoSize = true;
            this.allRequiredMessage.ForeColor = System.Drawing.Color.Red;
            this.allRequiredMessage.Location = new System.Drawing.Point(358, 326);
            this.allRequiredMessage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.allRequiredMessage.Name = "allRequiredMessage";
            this.allRequiredMessage.Size = new System.Drawing.Size(0, 20);
            this.allRequiredMessage.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(192, 312);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 20);
            this.label3.TabIndex = 12;
            this.label3.Text = "Address";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(346, 299);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(409, 102);
            this.richTextBox1.TabIndex = 13;
            this.richTextBox1.Text = "";
            // 
            // allMessage
            // 
            this.allMessage.AutoSize = true;
            this.allMessage.Location = new System.Drawing.Point(346, 423);
            this.allMessage.Name = "allMessage";
            this.allMessage.Size = new System.Drawing.Size(0, 20);
            this.allMessage.TabIndex = 14;
            // 
            // warning
            // 
            this.warning.AutoSize = true;
            this.warning.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.warning.ForeColor = System.Drawing.Color.Red;
            this.warning.Location = new System.Drawing.Point(350, 423);
            this.warning.Name = "warning";
            this.warning.Size = new System.Drawing.Size(0, 13);
            this.warning.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1045, 532);
            this.Controls.Add(this.warning);
            this.Controls.Add(this.allMessage);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.allRequiredMessage);
            this.Controls.Add(this.saveBtn);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.passwordRequired);
            this.Controls.Add(this.passwordLabel);
            this.Controls.Add(this.emailRequired);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.nameRequired);
            this.Controls.Add(this.nameFiled);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nameLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Customer Registration Form ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nameFiled;
        private System.Windows.Forms.Label nameRequired;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label emailRequired;
        private System.Windows.Forms.Label passwordLabel;
        private System.Windows.Forms.Label passwordRequired;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.Label allRequiredMessage;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label allMessage;
        private System.Windows.Forms.Label warning;
    }
}

