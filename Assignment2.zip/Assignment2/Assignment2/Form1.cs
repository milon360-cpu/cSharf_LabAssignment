﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
namespace Assignment2
{
    public partial class Form1 : Form
    {
        string pattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
        bool flag = false;
        public Form1()
        {
            InitializeComponent();
        }

        
        // name filed  
        private void nameFiled_TextChanged(object sender, EventArgs e)
        {
            if(nameFiled.Text.Trim() == "")
            {
                nameRequired.Text = "Name is Required";
            }
            else
            {

                nameRequired.Text = "*";
            }
        } 
        //Email Filed 
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(textBox1.Text.Trim() == "")
            {
                emailRequired.Text = "Email is Required";
            }
            else
            {
                Regex regex = new Regex(pattern);
                string email = textBox1.Text.Trim();
                Match match = regex.Match(email);
                if (!match.Success)
                {
                    emailRequired.Text = "Invlid Email Address";
                    flag = false;
                }
                else
                {
                    emailRequired.Text = "*";
                    flag = true;
                }
               
                
            }
        }

        //Phone Filed 
        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Trim() == "")
            {
                passwordRequired.Text = "Phone is Required";
            }
            else
            {
                passwordRequired.Text = "*";
            }
        }

        // Button 
        private void saveBtn_Click(object sender, EventArgs e)
        {
            if (nameFiled.Text.Trim() != "" && textBox2.Text.Trim() != "" && textBox1.Text.Trim() != "" && flag)
            {
                warning.Text = "";
                MessageBox.Show("Save Data Successfully");
            }
            else if(!flag)
            {
                warning.Text = "Invalid Email Address";
            }
            else
            {
                warning.Text = "fill the all required filed";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
